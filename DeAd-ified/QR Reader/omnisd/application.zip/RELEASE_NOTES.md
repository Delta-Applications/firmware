## v1.4.40

* Add timeout for ads loading

### v1.4.50
* Add ads-sdk v3

### v1.4.60
* Add related logic when scanning a text code

### v1.4.70
* bug fixed

### v1.4.80
* bug fixed

### v1.5.00
* Add scripts to compile next version on master branch.

### v1.5.01
* Bug fixed

### v1.5.02
* Bug fixed

### v1.5.03
* Add zh-HK and zh-TW translation for QR code reader

### v1.5.04
* Bug fixed

### v1.5.05
* Add permission declaration to meet China Type Approval requirement.

### v1.5.06
* Add vi-VN locale for QR reader.

### v1.5.08
* Add an ability to scan inverted(white on black) codes.