Simple QR-Code reader as an alternative to KaiOS's Ad filled one 
-- This was planned to be replaced with Cyan's QR Reader, but it's in the works and may get released in a few months without crowdfunding.
Meanwhile, here's an ad-less version of the QR Reader provided by KaiOS Team! The SDK and other assets are kept to make the QR Reader work, but the internal code has been beautified and the window.ads.show have been replaced with what would have happened if the Ad showed, hope you like it! KaiWeather may be provided soon! 
![scan_mask](https://user-images.githubusercontent.com/26120324/128858071-882d9e03-20b7-4b98-ade9-44560ac1bc0d.png)  
![scan_mask_lnd](https://user-images.githubusercontent.com/26120324/128858081-727e1c0b-bd6b-4de8-8871-ae2b13119879.png)  
